package com.sender.Service;

import org.springframework.stereotype.Service;

import com.sender.dto.ResponseDto;
@Service
public class SenderImpl implements Sender {

	@Override
	public ResponseDto sender(ResponseDto responseDto) {
		
		return responseDto;
	}

}
