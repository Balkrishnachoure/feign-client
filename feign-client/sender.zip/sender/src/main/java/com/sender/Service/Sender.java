package com.sender.Service;

import com.sender.dto.ResponseDto;

public interface Sender {
	
	public ResponseDto sender(ResponseDto responseDto);

}
