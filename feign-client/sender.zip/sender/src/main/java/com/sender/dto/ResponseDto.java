package com.sender.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseDto {
	
	 private String status= "OK"; 
	 private String statusCode = "SUCCESS"; 

	 private String access_token=
	"eyJ0eXAiOiJhY2Nlc3NfdG9rZW4iLCJhbGciOiJIUzI1NiJ9.eyJzdWI1OiJhZmlzX3VzZXIiLCJyb2xlcyI6"
	+ "WyJBRklTX1ZFUklGSUNBVElPKiJkLCJpYXQiOjE1NjY4MjQxNTIsImV4cCI6XXX2mjgyNzc1Mn0.vrbtvXXXRyREJ0xKmK5auqc0N_5cMsEbmb221K8VbDs"; 
	 private String refresh_token=  
	"eyJ0eXAiOiJyZWZyZXNoX3Rva2VuIiwiYWxnIjoiSFMyMTY1fQ.eyJzdWIiOiJhZmlzX3VzZXI1LCJpYXQiOj"
	+ "E1NjY4Mj8xXXIs1mV4cC16XXU2NjgzXXX1Mn0.J6lAxUyWefXTSmxmzivj0fGu0agxy5C1qKVzAcf2AWA";
	
}
