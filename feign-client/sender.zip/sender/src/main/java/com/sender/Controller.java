package com.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sender.Service.Sender;
import com.sender.dto.ResponseDto;


@RestController
@RequestMapping("/sender")
public class Controller {
	
	@Autowired
	private Sender sender;
	@GetMapping("/data")
	public ResponseDto sender(ResponseDto responseDto) {
		return this.sender.sender(responseDto);
	}

}
