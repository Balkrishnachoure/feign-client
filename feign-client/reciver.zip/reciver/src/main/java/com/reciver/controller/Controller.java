package com.reciver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.reciver.dto.ReciverResponseDto;
import com.reciver.service.Reciver;
import com.reciver.util.Feign;

@RestController
@RequestMapping("/reciver")
public class Controller {
	@Autowired
	private Reciver reciver;
	
	@Autowired
	private Feign feign;

	@GetMapping("/data")
	public ReciverResponseDto recive() {
		//return this.reciver.recive(reciverResponseDto);
		return feign.getData();

	}

}
