package com.reciver.service;

import com.reciver.dto.ReciverResponseDto;

public interface Reciver {
	
	public ReciverResponseDto recive (ReciverResponseDto reciverResponseDto);

}
