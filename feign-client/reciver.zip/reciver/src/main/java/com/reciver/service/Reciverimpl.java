package com.reciver.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.reciver.dto.ReciverResponseDto;
import com.reciver.util.Feign;

@Service
public class Reciverimpl implements Reciver {

	@Autowired
	private Feign feign;

	@Override
	public ReciverResponseDto recive(ReciverResponseDto reciverResponseDto) {

		// return this.feign.getData(reciverResponseDto);
		return null;
	}

}
