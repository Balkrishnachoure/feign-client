package com.reciver.util;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.reciver.dto.ReciverResponseDto;

@FeignClient(value = "Feign", url = "http://localhost:8080/sender/")
public interface Feign {

	@GetMapping("/data")
	ReciverResponseDto getData();

}
